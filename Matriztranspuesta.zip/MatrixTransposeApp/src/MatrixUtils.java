import java.util.Arrays;

public class MatrixUtils {
    
    // Método que calcula la transpuesta de una matriz
    public static double[][] transpose(double[][] matrix) {
        int rows = matrix.length;
        int cols = matrix[0].length;

        // Usamos lambda y streams para transponer la matriz
        double[][] transposedMatrix = new double[cols][rows];
        Arrays.stream(matrix)
              .forEach(row -> {
                  int rowIndex = Arrays.asList(matrix).indexOf(row);
                  for (int colIndex = 0; colIndex < row.length; colIndex++) {
                      transposedMatrix[colIndex][rowIndex] = row[colIndex];
                  }
              });

        return transposedMatrix;
    }
}