package funcioneslambda;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Diagonal extends JFrame {
    private JPanel Principal;
    private JTable table1;
    private JButton generarMatrizButton;
    private JTable table2;
    private JTextField valor;
    private JLabel Diagonal;
    MatrizDiagonal ind = new MatrizDiagonal();

    public Diagonal() {
        setContentPane(Principal);
        generarMatrizButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int[][] matriz = ind.generateRandomMatrix(Integer.parseInt(valor.getText()),Integer.parseInt(valor.getText()),1,100);
                table1.setModel(ind.getModel(matriz));
                int[][] matrizD = ind.obtenerMatrizDiagonal(matriz);
                table2.setModel(ind.getModel(matrizD));
            }
        });

    }
    public static void main(String[] args) {
        Diagonal frame = new Diagonal();
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
    }
}
