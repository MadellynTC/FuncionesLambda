package funcioneslambda;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.Random;

public class MatrizDiagonal extends JFrame {
    private static final Random RANDOM = new Random();

    public static int[][] generateRandomMatrix(int rows, int cols, int minValue, int maxValue) {
        int[][] matrix = new int[rows][cols];

        fillMatrix(matrix, 0, 0, minValue, maxValue);
        return matrix;
    }

    private static void fillMatrix(int[][] matrix, int row, int col, int minValue, int maxValue) {
        if (row >= matrix.length) return;

        if (col >= matrix[row].length) {
            fillMatrix(matrix, row + 1, 0, minValue, maxValue);
            return;
        }

        matrix[row][col] = RANDOM.nextInt(maxValue - minValue + 1) + minValue;

        fillMatrix(matrix, row, col + 1, minValue, maxValue);
    }

    public DefaultTableModel getModel(int[][] matriz) {
        DefaultTableModel model = new DefaultTableModel(matriz.length, matriz[0].length);

        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                model.setValueAt(matriz[i][j], i, j);
            }
        }

        return model;
    }

    public static int[][] obtenerMatrizDiagonal(int[][] matriz) {
        int filas = matriz.length;
        int columnas = matriz[0].length;

        if (filas != columnas) {
            throw new IllegalArgumentException("La matriz debe ser cuadrada para crear una matriz diagonal.");
        }

        int[][] diagonal = new int[filas][columnas];

        // Crear la matriz diagonal
        for (int i = 0; i < filas; i++) {
            diagonal[i][i] = matriz[i][i];
        }

        return diagonal;
    }


}
