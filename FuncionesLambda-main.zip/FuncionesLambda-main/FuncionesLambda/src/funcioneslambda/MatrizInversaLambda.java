/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package funcioneslambda;

import Interfaces.FrameMatrizInversaVillacres;

/**
 *
 * @author MIGUEL VILLACRES
 */
public class MatrizInversaLambda {

    public static void main(String[] args) {
        // Crear una instancia de la ventana
        FrameMatrizInversaVillacres ventana = new FrameMatrizInversaVillacres();
        // Hacer la ventana visible
        ventana.setVisible(true);
    }
}
